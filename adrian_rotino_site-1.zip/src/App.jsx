import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, Instagram, Youtube, SunMoon } from "lucide-react";

export default function AdrianAdaleRotino() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-black to-gray-900 text-white p-6">
      {/* Hero Section */}
      <section className="text-center py-20">
        <h1 className="text-5xl font-bold mb-4">Adrian Adale Rotino</h1>
        <p className="text-xl text-gray-300">Creator • Visionary • Storyteller</p>
        <div className="mt-4">
          <Button variant="ghost" className="text-white border border-gray-500">
            <SunMoon className="h-5 w-5 mr-2" /> Toggle Theme
          </Button>
        </div>
      </section>

      {/* About Section */}
      <section className="max-w-3xl mx-auto mb-16">
        <Card className="bg-gray-800">
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-2">About Me</h2>
            <p className="text-gray-300">
              I’m Adrian Adale Rotino — a multidisciplinary creator passionate about telling stories
              through visuals, words, and sound. Whether it’s through digital media, short films,
              photography, or design, I strive to spark emotion and connection.
            </p>
          </CardContent>
        </Card>
      </section>

      {/* Portfolio Section */}
      <section className="max-w-5xl mx-auto mb-16">
        <h2 className="text-3xl font-bold mb-6">Featured Work</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {["Documentary Short", "Digital Collage", "Music Video"].map((title, i) => (
            <Card key={i} className="bg-gray-800">
              <CardContent className="p-4">
                <div className="h-40 bg-gray-700 rounded mb-4"></div>
                <h3 className="text-xl font-semibold mb-1">{title}</h3>
                <p className="text-gray-400 text-sm">Description for {title.toLowerCase()} project.</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Media Gallery Section */}
      <section className="max-w-5xl mx-auto mb-16">
        <h2 className="text-3xl font-bold mb-6">Media Gallery</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[1, 2].map((i) => (
            <div key={i} className="aspect-w-16 aspect-h-9">
              <iframe
                className="w-full h-full rounded shadow"
                src={`https://www.youtube.com/embed/sample${i}`}
                title={`YouTube video ${i}`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
          ))}
        </div>
      </section>

      {/* Contact Section */}
      <section className="text-center py-10 border-t border-gray-700">
        <h2 className="text-2xl font-bold mb-4">Let’s Connect</h2>
        <div className="flex justify-center gap-4 mb-6">
          <Button variant="outline" size="icon" className="border-gray-500" asChild>
            <a href="mailto:adrian@example.com" aria-label="Email">
              <Mail className="h-5 w-5" />
            </a>
          </Button>
          <Button variant="outline" size="icon" className="border-gray-500" asChild>
            <a href="https://instagram.com/adrianrotino" target="_blank" aria-label="Instagram">
              <Instagram className="h-5 w-5" />
            </a>
          </Button>
          <Button variant="outline" size="icon" className="border-gray-500" asChild>
            <a href="https://youtube.com/@adrianrotino" target="_blank" aria-label="YouTube">
              <Youtube className="h-5 w-5" />
            </a>
          </Button>
        </div>
        <p className="text-gray-500 text-sm">adrian@example.com</p>
      </section>
    </main>
  );
}
